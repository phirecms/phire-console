<?php

namespace Phire\Console\Controller;

class ArchiveController extends ConsoleController
{

    /**
     * Archive index action method
     *
     * @return void
     */
    public function index()
    {
        echo '    Archive';
    }

}
